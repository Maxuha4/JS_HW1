//Задание 6/ Найти площадь трапеции

// S=½h(a+b)

let hTrap=10,
    aTrap=5,
    bTrap=7,
    STrap=hTrap/2*(aTrap+bTrap);

    console.log(STrap +'м²');

