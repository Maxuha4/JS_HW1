//Задание4/ Найти объем цилиндра.

// V=πr²*H

let π=3.14,
    H=10,
    D=4;
    VCilindra= π*(D/2)**2*H

console.log(VCilindra +'м³');

