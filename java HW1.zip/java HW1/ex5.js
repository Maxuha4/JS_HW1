// Задание 5/ Найти площадь круга

//S=πr²

let r=5,
    πKruga=3.14,
    SKruga=πKruga*r**2;
    
console.log(SKruga +'м²');

