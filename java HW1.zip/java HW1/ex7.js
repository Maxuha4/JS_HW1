// Задание 7/ Найти переплату по кредиту

let S=2000000,
    p=0.1,
    year=5,
    Pereplata=((S/year)*p)*year;

console.log(Pereplata + 'руб');
