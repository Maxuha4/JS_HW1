// Задание 3/  Найти площадь прямоугольника


let width =23,
    height=10,
    SPryam=width*height;

console.log(SPryam +'см');